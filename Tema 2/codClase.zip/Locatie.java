public class Locatie {

	private double latitudine;
	private double longitudine;

	public Locatie(double latitudine, double longitudine){
		this.latitudine = latitudine;
		this.longitudine = longitudine;
	}
	
	public double getLatitudine() {
		return this.latitudine;
	}

	public void setLatitudine(double latitudine) {
		this.latitudine = latitudine;
	}

	public double getLongitudine() {
		return this.longitudine;
	}

	public void setLongitudine(double longitudine) {
		this.longitudine = longitudine;
	}

}