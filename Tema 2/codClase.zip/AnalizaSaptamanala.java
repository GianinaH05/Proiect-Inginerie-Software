public class AnalizaSaptamanala {

	private double temperaturaMinima;
	private double temperaturaMaxima;
	private double temperaturaMedie;
	private double numar;

	public AnalizaSaptamanala(){
		temperaturaMaxima = Math.random()*20;
		temperaturaMinima = temperaturaMaxima-20;
		temperaturaMedie = (temperaturaMaxima + temperaturaMinima)/2;
		numar = 10;
	}

	public double getTemperaturaMinima() {
		return this.temperaturaMinima;
	}

	public void setTemperaturaMinima(int temperaturaMinima) {
		this.temperaturaMinima = temperaturaMinima;
	}

	public double getTemperaturaMaxima() {
		return this.temperaturaMaxima;
	}


	public void setTemperaturaMaxima(int temperaturaMaxima) {
		this.temperaturaMaxima = temperaturaMaxima;
	}

	public double getTemperaturaMedie() {
		return this.temperaturaMedie;
	}


	public void setTemperaturaMedie(double temperaturaMedie) {
		this.temperaturaMedie = temperaturaMedie;
	}

	public String creeazaAnaliza() {
		StringBuffer s = new StringBuffer();
		s.append("---Analiza Saptamanala---\n");
		s.append("Temperatura Minima: ");
		s.append(temperaturaMinima);
		s.append(" Temperatura Maxima: ");
		s.append(temperaturaMaxima);
		s.append(" Temperatura Medie: ");
		s.append(temperaturaMedie);
		return s.toString();
	}

	public void addTemperatura(Locatie locatie){
		double temp = StareaVremii.getTemperatura(locatie);
		temperaturaMedie = (temperaturaMedie * numar + StareaVremii.getTemperatura(locatie))/(numar+1);
		numar = numar+1;
		if(temp > temperaturaMaxima)
			temperaturaMaxima = temp;
		if(temp < temperaturaMinima)
			temperaturaMinima = temp;
	}
}