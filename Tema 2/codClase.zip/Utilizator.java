public class Utilizator {

	private String nume;
	private Locatie locatie;

	public Utilizator(String nume, Locatie locatie){
		this.nume = nume;
		this.locatie = locatie;
	}

	public String getNume() {
		return this.nume;
	}

	public void setNume(String nume) {
		this.nume = nume;
	}

	public Locatie getLocatie() {
		return this.locatie;
	}

	public void setLocatie(Locatie locatie) {
		this.locatie = locatie;
	}

	public void afiseazaStareaVremii() {
		System.out.println(StareaVremii.afisare(this.locatie));
	}

	public void vizualizarePredictiiViitoare() {
		//Vede predictiile viitoare
	}

	public void vizualizareAnalizaSaptamanala() {
		AnalizaSaptamanala ana = new AnalizaSaptamanala();
		ana.addTemperatura(locatie);
		System.out.println(ana.creeazaAnaliza());
	}

	public void vizualizareAlerta(){
		//Vede alertele
	}
}