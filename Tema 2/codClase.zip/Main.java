public class Main {
    public static void main(String[] args) {
        Locatie loc = new Locatie(0, 0);
        Utilizator Utilizator1 = new Utilizator("George", loc);

        StareaVremii.adaugaSenzor(new Senzor(new Locatie(1, 7)));
        StareaVremii.adaugaSenzor(new Senzor(new Locatie(4,2)));
        StareaVremii.adaugaSenzor(new Senzor(new Locatie(1, 3)));
        StareaVremii.adaugaSenzor(new Senzor(new Locatie(4,3)));
        StareaVremii.adaugaSenzor(new Senzor(new Locatie(5, 7)));
        StareaVremii.adaugaSenzor(new Senzor(new Locatie(9,5)));
        StareaVremii.adaugaSenzor(new Senzor(new Locatie(91, 7)));
        StareaVremii.adaugaSenzor(new Senzor(new Locatie(43,5)));
        StareaVremii.adaugaSenzor(new Senzor(new Locatie(1, 71)));
        StareaVremii.adaugaSenzor(new Senzor(new Locatie(41,5)));
        
        Utilizator1.afiseazaStareaVremii();
        Utilizator1.vizualizareAnalizaSaptamanala();
    }
}
