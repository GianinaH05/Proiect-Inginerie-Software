public class Senzor {

	private double temperatura;
	private double umiditate;
	private double precipitatii;
	private double punctDeRoua;
	private double presiune;
	private Locatie locatie;

	public Senzor(Locatie locatie){
		this.locatie = locatie;
		actualizareDate();
	}

	public double getTemperatura() {
		return this.temperatura;
	}

	public double getUmiditate() {
		return this.umiditate;
	}

	public double getPrecipitatii() {
		return this.precipitatii;
	}

	public double getPunctDeRoua() {
		return this.punctDeRoua;
	}

	public double getPresiune() {
		return this.presiune;
	}

	public Locatie getLocatie() {
		return this.locatie;
	}

	public void setLocatie(Locatie locatie) {
		this.locatie = locatie;
	}

	private void actualizareDate() {
		//update date din senzor
		temperatura = Math.random()*20;
		umiditate = Math.random()*100;
		precipitatii = Math.random()*20;
		punctDeRoua = Math.random()*20;
		presiune = Math.random()*20;
	}

}