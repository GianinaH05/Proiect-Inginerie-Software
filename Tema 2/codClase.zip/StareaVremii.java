import java.util.ArrayList;
import java.util.List;
public class StareaVremii {

	private static List<Senzor> senzori = new ArrayList<>();


	public static double getTemperatura(Locatie locatie) {
		double temp = 0;
		int nr = 0;
		for(Senzor s : senzori){
			double lat = s.getLocatie().getLatitudine()-locatie.getLatitudine();
			double lon = s.getLocatie().getLongitudine()-locatie.getLongitudine();
			double dis = Math.sqrt(lat*lat + lon*lon);
			if(dis<=10)
			{
				temp = temp + s.getTemperatura();
				nr++;
			}
		}
		temp = temp/nr;
		return temp;
	}

	public static double getUmiditate(Locatie locatie) {
		double temp = 0;
		int nr = 0;
		for(Senzor s : senzori){
			double lat = s.getLocatie().getLatitudine()-locatie.getLatitudine();
			double lon = s.getLocatie().getLongitudine()-locatie.getLongitudine();
			double dis = Math.sqrt(lat*lat + lon*lon);
			if(dis<=10)
			{
				temp = temp + s.getUmiditate();
				nr++;
			}
		}
		temp = temp/nr;
		return temp;
	}

	public static double getPrecipitatii(Locatie locatie) {
		double temp = 0;
		int nr = 0;
		for(Senzor s : senzori){
			double lat = s.getLocatie().getLatitudine()-locatie.getLatitudine();
			double lon = s.getLocatie().getLongitudine()-locatie.getLongitudine();
			double dis = Math.sqrt(lat*lat + lon*lon);
			if(dis<=10)
			{
				temp = temp + s.getPrecipitatii();
				nr++;
			}
		}
		temp = temp/nr;
		return temp;
	}

	public static double getPresiune(Locatie locatie) {
		double temp = 0;
		int nr = 0;
		for(Senzor s : senzori){
			double lat = s.getLocatie().getLatitudine()-locatie.getLatitudine();
			double lon = s.getLocatie().getLongitudine()-locatie.getLongitudine();
			double dis = Math.sqrt(lat*lat + lon*lon);
			if(dis<=10)
			{
				temp = temp + s.getPresiune();
				nr++;
			}
		}
		temp = temp/nr;
		return temp;
	}

	public static double getPunctRoua(Locatie locatie) {
		double temp = 0;
		int nr = 0;
		for(Senzor s : senzori){
			double lat = s.getLocatie().getLatitudine()-locatie.getLatitudine();
			double lon = s.getLocatie().getLongitudine()-locatie.getLongitudine();
			double dis = Math.sqrt(lat*lat + lon*lon);
			if(dis<=10)
			{
				temp = temp + s.getPunctDeRoua();
				nr++;
			}
		}
		temp = temp/nr;
		return temp;
	}

	public static void reprezentareGrafica(Locatie locatie) {
		// reprezentarea grafica pentru starea vremii
	}

	public static void adaugaSenzor(Senzor senzor) {
		senzori.add(senzor);
	}

	public static void eliminaSenzor(Senzor senzor) {
		senzori.removeIf(s -> s == senzor);
	}

	public static String afisare(Locatie locatie){
		StringBuffer s = new StringBuffer();
		s.append("---Starea vremii---\n");
		s.append("Temperatura: ");
		s.append(getTemperatura(locatie));
		s.append("\n");
		s.append("Umiditate: ");
		s.append(getUmiditate(locatie));
		s.append("\n");
		s.append("Presiune: ");
		s.append(getPresiune(locatie));
		s.append("\n");
		s.append("Precipitatii: ");
		s.append(getPrecipitatii(locatie));
		s.append("\n");
		s.append("Punct de roua: ");
		s.append(getPunctRoua(locatie));
		s.append("\n");
		return s.toString();
	}
}